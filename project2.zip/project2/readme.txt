db.product.insert[{
    
}]