var express = require('express');
var mongoose = require('mongoose')
var db= require("./database/db.js")
db ();
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const usersschema= new Schema({
  name: String,
  price: Number,
  discount: Number
});
const usersModel = mongoose.model('product', usersschema);
var express = require('express');
var app = express();
app.use(express.json());
app.get('/product', async (req,res)=>{
//res.send('fetch data from database');
try{
    var result =await usersModel.find()
    res.send(result);
    
}catch(err){
res.send(err.message);
}
})

app.post("/product",async function (req,res){
    console.log(req.body);
    try{
var record =new usersModel(req.body)
    var ans = await record.save();
    res.send ("record inserted");
    }catch(err){
        res.send(err.message);
    }
})
   
app.listen(7000)