var mongoose = require('mongoose');
var db= require("./database/db.js")
//mysql
var mysql   = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'password',
  database : 'cdac'
});
//console.log(db)
db ();
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const usersschema= new Schema({
  name: String,
  age: Number,
  place: String
});
const usersModel = mongoose.model('users', usersschema);
var express = require('express');
var app = express();
app.use(express.json());
app.get('/users', async (req,res)=>{
//res.send('fetch data from database');
try{
    var result =await usersModel.find()
    res.send(result);
    
}catch(err){
res.send(err.message);
}
})

app.post("/users",async function (req,res){
    console.log(req.body);
    try{
var record =new usersModel(req.body)
    var ans = await record.save();
    res.send ("record inserted");
    }catch(err){
        res.send(err.message);
    }
})
    app.put('/users',(req,res)=>{
        res.send('put data from database');
        })
        app.delete('/users',(req,res)=>{
            res.send('delete data from database');
            })
//mysql
app.get('/usersinfo',async function (req,res){
connection.query("select * from emp", function(err,result){
    if(err) {
    req.send(err.message);
    }
    else{
        res.send(result);
    }
})
})
app.post("/usersinfo",function(req,res){
 console.log(req.body);  
 connection.query(
    "insert into emp set ? ",
    req.body,
    function (err, result) {
    if(err){
        res.send(err.message)
    }else{
        res.send("user added")
    }
    }
 )
})
app.listen(9494)
